import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoutingNewCompComponent } from './routing-new-comp.component';

describe('RoutingNewCompComponent', () => {
  let component: RoutingNewCompComponent;
  let fixture: ComponentFixture<RoutingNewCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoutingNewCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoutingNewCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
