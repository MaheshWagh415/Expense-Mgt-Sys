import { Component, OnInit } from '@angular/core';
import { EmpDataServiceService } from '../emp-data-service.service';
import { InterfaceEmp } from '../interface-emp';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [EmpDataServiceService]
})
export class EmployeeComponent implements OnInit {
  empList: InterfaceEmp[];
  // private empservice: EmpDataServiceService
  constructor(private empService: EmpDataServiceService) {
  }


  ngOnInit() {
    // this.empList = this.empservice.getEmpList();
    this.empService.getEmpData().subscribe(user => this.empList = user);
  }

}
