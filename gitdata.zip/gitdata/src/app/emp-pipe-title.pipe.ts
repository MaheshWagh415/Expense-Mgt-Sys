import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'empPipeTitle'
})
export class EmpPipeTitlePipe implements PipeTransform {

  transform(name: string, gender: string, ...args: any[]): any {
    // tslint:disable-next-line: triple-equals
    if (gender.toLowerCase() == 'male') {
      return 'Mr. ' + name;
    } else {
      return 'Miss. ' + name;
    }
  }

}
