import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-login-comp',
  templateUrl: './login-comp.component.html',
  styleUrls: ['./login-comp.component.css']
})
export class LoginCompComponent implements OnInit {
  formdata;
  constructor() { }

  ngOnInit() {
    this.formdata = new FormGroup({
      uname: new FormControl("", Validators.compose([
        Validators.required,
        Validators.minLength(6)
      ])),
      password: new FormControl("", this.passwordValidator
      )
    });
  }
  passwordValidator(formcontrol) {
    if (formcontrol.value.length < 5) {
      return { "Password": true }
    }
  }

  onClickSubmit(data) {
    console.log(data.uname);
    if (data.uname == 'mahesh' && data.password == 'Waghmahi') {
      alert('Login Successfully');
    }
    else {
      alert("Invalid Login");
    }
  }
}


