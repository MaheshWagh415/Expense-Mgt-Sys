import { Injectable } from '@angular/core';
import { InterfaceEmp } from './interface-emp';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class EmpDataServiceService {
  constructor(private _http: HttpClient) {
  }
  // getEmpList(): InterfaceEmp[] {
  // return this.employeeList;
  // }
  // tslint:disable-next-line: member-ordering
  // employeeList: InterfaceEmp[] = [
  //   {
  //     code: 'emp1', name: 'pandu', gender: 'Male', annualSalary: 2000000, dateOfBirth: '02/12/2020'
  //   },
  //   {
  //     code: 'emp2', name: 'parshu', gender: 'Male', annualSalary: 4000000, dateOfBirth: '05/12/2016'
  //   },
  //   {
  //     code: 'emp3', name: 'mahi', gender: 'Male', annualSalary: 6000000, dateOfBirth: '08/12/2017'
  //   },
  //   {
  //     code: 'emp4', name: 'patlu', gender: 'Male', annualSalary: 8000000, dateOfBirth: '07/15/2018'
  //   },
  //   {
  //     code: 'emp5', name: 'jacky', gender: 'Female', annualSalary: 1000000, dateOfBirth: '07/12/2018'
  //   },
  //   {
  //     code: 'emp6', name: 'pinti', gender: 'Female', annualSalary: 2000000, dateOfBirth: '07/1/2018'
  //   },
  //   {
  //     code: 'emp7', name: 'chinti', gender: 'Female', annualSalary: 3000000, dateOfBirth: '07/2/2018'
  //   },
  // ];
  getEmpData(): Observable<InterfaceEmp[]> {
    const httpOptions = {
      headers: new HttpHeaders(
        {
          'Access-Control-Allow-Origin': 'http://localhost:4200/'
        }
      )
    };
    return this._http.get<InterfaceEmp[]>('https://jsonplaceholder.typicode.com/users', httpOptions);
  }


}
