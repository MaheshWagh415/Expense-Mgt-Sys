import { EmpPipeTitlePipe } from './emp-pipe-title.pipe';

describe('EmpPipeTitlePipe', () => {
  it('create an instance', () => {
    const pipe = new EmpPipeTitlePipe();
    expect(pipe).toBeTruthy();
  });
});
