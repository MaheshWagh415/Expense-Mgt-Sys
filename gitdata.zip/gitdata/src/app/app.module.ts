import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyFirstCompComponent } from './my-first-comp/my-first-comp.component';
import { LoginCompComponent } from './login-comp/login-comp.component';
import { from } from 'rxjs';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RoutingNewCompComponent } from './routing-new-comp/routing-new-comp.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmpPipeTitlePipe } from './emp-pipe-title.pipe';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    MyFirstCompComponent,
    LoginCompComponent,
    AboutComponent,
    HomeComponent,
    PageNotFoundComponent,
    RoutingNewCompComponent,
    EmployeeComponent,
    EmpPipeTitlePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
