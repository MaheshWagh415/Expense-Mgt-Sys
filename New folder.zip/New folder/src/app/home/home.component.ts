import { Component, OnInit } from '@angular/core';
import { ViewExpense } from '../view-expense';
import { ViewaddexpenseService } from '../viewaddexpense.service';
import { from } from 'rxjs';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  viewExp: ViewExpense[];
  constructor(private getExpense: ViewaddexpenseService) { }

  ngOnInit() {
    this.getExpense.getExpenseData().subscribe(expense => this.viewExp = expense);
  }

}
