import { Injectable } from '@angular/core';
import { ViewExpense } from './view-expense';
import { GetCategory } from './view-expense';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ViewaddexpenseService {

  constructor(private httpGet: HttpClient) { }
  getExpenseData(): Observable<ViewExpense[]> {
    const httpOptions = {
      headers: new HttpHeaders(
        {
          'Access-Control-Allow-Origin': 'http://localhost:4200/'
        }
      )
    };
    return this.httpGet.get<ViewExpense[]>('http://localhost:3004/routes/getAllExpeses', httpOptions);
  }
  getCategory(): Observable<GetCategory[]> {
    const httpOptions = {
      headers: new HttpHeaders(
        {
          'Access-Control-Allow-Origin': 'http://localhost:4200/'
        }
      )
    };
    return this.httpGet.get<GetCategory[]>('http://localhost:3004/routes/cotegories', httpOptions);
  }
  addNewExpense(): Observable<ViewExpense[]> {
    const httpOptions = {
      headers: new HttpHeaders(
        {
          'Content-type': 'application/json',
          'Access-Control-Allow-Origin': 'http://localhost:4200/'
        }
      )
    };
    return this.httpGet.get<ViewExpense[]>('http://localhost:3004/routes/addExpenses', httpOptions);
  }
}
