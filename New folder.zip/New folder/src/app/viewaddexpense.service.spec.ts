import { TestBed } from '@angular/core/testing';

import { ViewaddexpenseService } from './viewaddexpense.service';

describe('ViewaddexpenseService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewaddexpenseService = TestBed.get(ViewaddexpenseService);
    expect(service).toBeTruthy();
  });
});
