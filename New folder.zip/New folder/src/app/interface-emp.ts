export interface InterfaceEmp {
    // code: string;
    // name: string;
    // gender: string;
    // annualSalary: number;
    // dateOfBirth: string;
    id: number;
    name: string;
    username: string;
    email: string;
}
