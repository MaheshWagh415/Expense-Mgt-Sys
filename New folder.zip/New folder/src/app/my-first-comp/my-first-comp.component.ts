import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-first-comp',
  templateUrl: './my-first-comp.component.html',
  styleUrls: ['./my-first-comp.component.css']
})
export class MyFirstCompComponent implements OnInit {

  // tslint:disable-next-line: ban-types
  name: String = 'Mahesh';
  constructor() { }

  ngOnInit() {
  }

}
