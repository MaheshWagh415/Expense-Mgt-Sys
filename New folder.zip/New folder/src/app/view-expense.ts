export interface ViewExpense {
    categoryId: number;
    expenseId: number;
    expenseName: string;
    amount: number;
    create_Date: Date;
    update_Date: Date;
}
export interface GetCategory {
    categoryId: number;
    categoryName: string;
}
