import { Component, OnInit } from '@angular/core';
// import { ViewExpense } from '../view-expense';
import { GetCategory } from '../view-expense';
import { ViewaddexpenseService } from '../viewaddexpense.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-add-expense',
  templateUrl: './add-expense.component.html',
  styleUrls: ['./add-expense.component.css']
})
export class AddExpenseComponent implements OnInit {
  // addExp: ViewExpense[];
  getCatgr: GetCategory[];
  formdata;
  constructor(private getCatg: ViewaddexpenseService) { }

  ngOnInit() {
    this.formdata = new FormGroup({
      expenseType: new FormControl(),
      amount: new FormControl(),
      category: new FormControl()
    });
    JSON.stringify(this.getCatg.getCategory().subscribe(catg => this.getCatgr = catg));
    // console.log('catg', this.getCatgr);
  }
  onClickSubmit(data) {
    console.log('data', data);
  }

}
