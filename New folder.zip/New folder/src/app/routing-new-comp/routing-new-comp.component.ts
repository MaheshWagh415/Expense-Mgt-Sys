import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-routing-new-comp',
  templateUrl: './routing-new-comp.component.html',
  styleUrls: ['./routing-new-comp.component.css']
})
export class RoutingNewCompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
