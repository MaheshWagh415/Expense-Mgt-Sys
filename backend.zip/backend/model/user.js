const mongoose = require('mongoose');
const userSchema = mongoose.Schema({
    id: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    email: {
        type: String,
        unique: true,
        required: true
    },
    loginName: {
        type: String,
        required: true
    },
    Password: {
        type: String,
        minlength: [4, 'Must be greater then 4 Character'],
        required: true
    },
    roll: {
        type: String,
        required: true
    },
    status: {
        type: String,
        required: true
    }
})

const user = mongoose.model('user', userSchema);
module.exports = user;