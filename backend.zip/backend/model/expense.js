const mongoose = require('mongoose');
const expenseSchema = mongoose.Schema({
    categoryId: {
        type: mongoose.Schema.Types.String,
        ref: "category.categoryId"
    },
    expenseId: {
        type: String,
        required: true
    },
    expenseName: {
        type: String,
        required: true
    },
    amount: {
        type: String,
        required: true
    },
    create_Date: {
        type: Date,
        //default: Date.now
        required: true
    },
    update_Date: {
        type: Date,
        default: Date.now
    }
})
const expense = mongoose.model('Expense', expenseSchema);
module.exports = expense;