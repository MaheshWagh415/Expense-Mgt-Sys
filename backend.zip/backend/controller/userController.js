var user = require('../model/user.js');
exports.getUser = (req, res, next) => {
    user.find(function (err, user) {
        if (err) {
            res.json(err);
        } else {
            res.json(user);
        }
    })
};
exports.addUser = (req, res) => {
    let newUser = new user({
        id: req.body.id,
        name: req.body.name,
        phone: req.body.phone,
        email: req.body.email,
        loginName: req.body.loginName,
        Password: req.body.Password,
        roll: req.body.roll,
        status: req.body.status,
    });
    newUser.save((err) => {
        if (err) {
            res.json(err)
        } else {
            res.json({
                msg: "Added new user"
            })
        }
    })
};