const mongoose = require('mongoose');
const expenseSchema = mongoose.Schema({
    expenseId:{
        type:String,
        required:true
    },
    expenseName:{
        type:String,
        required:true
    },
    amount:{
        type: String,
        required: true
    },
    create_Date:{
        type:Date,
        default: Date.now
    },
    update_Date:{
        type:Date,
        default: Date.now
    }
})
const expense = mongoose.model('Expense', expenseSchema);
module.exports = expense;