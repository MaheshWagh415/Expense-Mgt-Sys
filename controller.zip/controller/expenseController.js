var expense = require('../model/expense.js');
exports.getExpense = (req,res,next) =>{
    expense.find(function(err, expense){
        if(err){
            res.json(err);
        }
        else{
            res.json(expense);
        }
    })
};
exports.addExpenses = (req,res)=>{
    let newExpense = new expense({
        expenseId: req.body.expenseId,
        expenseName: req.body.expenseName,
        amount: req.body.amount,
        create_Date: new Date,
        update_Date: new Date
    });
    newExpense.save((err) =>{
        if(err){
            res.json(err)
        }
        else{
            res.json({
                msg:"Added new expense"
            })
        }
    })
};
exports.updateExpeses = (req,res)=>{
    expense.findOneAndUpdate({
        "expenseId": req.body.expenseId
    },
   { $set:{
        amount: req.body.amount,
        update_Date: new Date
    }
},
    function(err){
        if(err){
            res.json(err)
        }
        else{
            res.json({Msg:'Expese details updated'})
        }
    }
    )
};
exports.deleteExpense = (req,res) =>{
    expense.remove({
        "expenseId": req.params.id
    },
    function(err){
        if(err){res.json(err)}
        else{
            res.json({
                msg:"Expense deleted"
            })
        }
    }
    )
}